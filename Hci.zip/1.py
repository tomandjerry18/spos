import tkinter as tk
from tkinter import ttk

class CryptoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Crypto Website")

        self.notebook = ttk.Notebook(root)

        login_signup_page = ttk.Frame(self.notebook)
        tk.Label(login_signup_page, text="Login/Signup Page").pack(padx=10, pady=10)
        self.notebook.add(login_signup_page, text="Login/Signup")

        graph_page = ttk.Frame(self.notebook)
        tk.Label(graph_page, text="Graph Page").pack(padx=10, pady=10)
        self.notebook.add(graph_page, text="Graph")

        search_page = ttk.Frame(self.notebook)
        tk.Label(search_page, text="Search Page").pack(padx=10, pady=10)
        self.notebook.add(search_page, text="Search")

        chart_page = ttk.Frame(self.notebook)
        tk.Label(chart_page, text="Chart Page").pack(padx=10, pady=10)
        self.notebook.add(chart_page, text="Chart")

        set_alert_page = ttk.Frame(self.notebook)
        tk.Label(set_alert_page, text="Set Alert Page").pack(padx=10, pady=10)
        self.notebook.add(set_alert_page, text="Set Alert")

        self.notebook.pack(expand=True, fill="both")

if __name__ == "__main__":
    root = tk.Tk()
    app = CryptoApp(root)
    root.geometry("600x400")
    root.mainloop()

