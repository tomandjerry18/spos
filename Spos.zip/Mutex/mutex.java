import java.util.Scanner;
import java.util.concurrent.Semaphore;

class mutex{

	static Semaphore readLock = new Semaphore(1);
	static Semaphore writeLock = new Semaphore(1);
	static int readcount = 0;
	
	static class Read implements Runnable {
	@Override
		public void run(){
		try{
			readLock.acquire();
			readcount++;
			if(readcount==1){
			writeLock.acquire();
			}
			readLock.release();
			
			System.out.println("Thread" + Thread.currentThread().getName() + "is started reading");
			Thread.sleep(2500);
			System.out.println("Thread" + Thread.currentThread().getName() + "is finished reading");
			
			readcount--;
			readLock.acquire();
			if(readcount==0){
			writeLock.release();
			}
			readLock.release();
		
		}
		catch(InterruptedException e){
		System.out.println(e.getMessage());
		}
		
		}
	
	
	}
	
	static class Write implements Runnable{
	@Override
		public void run(){
			try{
			writeLock.acquire();
			System.out.println("Thread" + Thread.currentThread().getName() + "is started writing");
			Thread.sleep(1000);
			System.out.println("Thread" + Thread.currentThread().getName() + "is finished writing");
			writeLock.release();
			
			
	
		
		}
		catch(InterruptedException e){
		System.out.println(e.getMessage());
		}
		}
	}
	
	
	
	
	
	public static void main(String[] args) throws Exception{
	Read read = new Read();
	Write write = new Write();
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter the number of processes : ");
	int n = sc.nextInt();
	
	System.out.println("Enter the sequences 0 for write 1 for read : ");
	
	int seq[] = new int[n];
	for(int i=0;i<n;i++){
	seq[i]=sc.nextInt();
	}
	
	Thread process[] = new Thread[n];
	for(int i=0;i<n;i++){
	if(seq[i]==1){
	process[i]=new Thread(read);
	process[i].setName("Thread"+(i+1));
	}
	else{
	process[i]=new Thread(write);
	process[i].setName("Thread"+(i+1));
	}
	}
	
	for(int i=0;i<n;i++){
	process[i].start();
	}
	
	sc.close();
	
	
	}
	


}
