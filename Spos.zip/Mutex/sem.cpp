#include <bits/stdc++.h>
using namespace std;

class RW {
public:
    mutex readMutex;
    mutex writeMutex;
    condition_variable cv;

    static int readCount;

    class Read {
    public:
        RW& rw;

        Read(RW& rw) : rw(rw) {}

        void operator()() {
            unique_lock<mutex> lock(rw.readMutex);
            rw.readCount++;

            if (rw.readCount == 1) {
                rw.writeMutex.lock();
            }

            lock.unlock();

            cout << "Thread " << this_thread::get_id() << " is reading." << endl;
            this_thread::sleep_for(chrono::milliseconds(2500));
            cout << "Thread " << this_thread::get_id() << " has finished reading." << endl;

            lock.lock();

            rw.readCount--;

            if (rw.readCount == 0) {
                rw.writeMutex.unlock();
            }

            lock.unlock();
        }
    };

    class Write {
    public:
        RW& rw;

        Write(RW& rw) : rw(rw) {}

        void operator()() {
            unique_lock<mutex> lock(rw.writeMutex);

            cout << "Thread " << this_thread::get_id() << " is writing." << endl;
            this_thread::sleep_for(chrono::milliseconds(1000));
            cout << "Thread " << this_thread::get_id() << " has finished writing." << endl;

            lock.unlock();
        }
    };

    void fun() {
        Read read(*this);
        Write write(*this);

        cout << "Enter the number of read & write processes: ";
        int n;
        cin >> n;

        vector<int> seq(n);

        cout << "Enter the sequence: 1 for reading & 0 for writing." << endl;
        for (int i = 0; i < n; i++) {
            cin >> seq[i];
        }

        vector<thread> processes;

        for (int i = 0; i < n; i++) {
            if (seq[i] == 1) {
                processes.emplace_back(read);
            } else if (seq[i] == 0) {
                processes.emplace_back(write);
            }
        }

        for (auto& thread : processes) {
            thread.join();
        }
    }
};

int RW::readCount = 0;

int main() {
    RW rw;
    rw.fun();

    return 0;
}

