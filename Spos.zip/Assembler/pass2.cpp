#include<bits/stdc++.h>
using namespace std;

int main(){
    fstream ic , mc , ltab , stab;
    ic.open("ic.txt" , ios::in);
    ltab.open("lit.txt" , ios::in);
    stab.open("sym.txt" , ios::in);
    mc.open("mc.txt" , ios::out);

    vector<int> st , lt;

    string sa , sb;
    while(getline(stab , sa)){
        int temp = 0;
        int x = sa.size();
        temp+= 100*(sa[x-3]-48);
        temp+= 10*(sa[x-2]-48);
        temp+=(sa[x-1]-48);
        st.push_back(temp);
    }


    while(getline(ltab , sb)){
        int temp = 0;
        int x = sb.size();
        temp+= 100*(sb[x-3]-48);
        temp+= 10*(sb[x-2]-48);
        temp+=(sb[x-1]-48);
        lt.push_back(temp);
    }


    string line;
    while(getline(ic , line)){
        string temp = "" , str="";
        int flag = 0 , last = 0;
        for(auto ch : line){
            if(ch == '('){
                temp = "";
                str = "";
            }
            else if(ch == ','){
                if(temp == "AD"){
                mc << endl;
                    flag = 1;
                    break;
                }
                str = temp;
                temp = "";
                continue;
            }
            else if(ch == ')'){
                if(temp == "00"){
                    last = 1;
                    break;
                }
                if(str != "S" and str != "L"){
                    if(str == "DL") mc << "00 00 ";
                    else mc << temp << " ";
                }
                else if(str == "S"){
                    int x = temp[1] - '0';
                    mc << st[x];
                }
                else if(str == "L"){
                    int x = temp[0] - '0';
                    mc << lt[x];
                }
                str = "";
            }else temp += ch;


        }
        if(flag == 1) continue;
        if(last == 1) break;
        mc << endl;
    }

}
