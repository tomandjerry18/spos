#include<bits/stdc++.h>
using namespace std;

int main() {
int x,y;
cout << "Enter the block size and process size : ";
cin >> x >> y;

int a[x],b[y];

cout << "Enter the sizes of process : ";
for(int i=0;i<y;i++){
cin >> b[i];
}

cout << "Enter the sizes of blocks : ";
for(int i=0;i<x;i++){
cin >> a[i];
}

int res[y];

for (int i = 0; i < y; i++) {
int mn=0,ind=0;
            for (int j = 0; j < x; j++) {
                if(a[j]>=b[i]){
                if(a[j]-b[i] > mn){
                mn = a[j]-b[i];
                ind = j;
                }
                }
            }
            res[i]=ind+1;
            a[ind]-=b[i];
        }


cout << "Process  " << "Process Size  " << "Block No" << endl;
for(int i=-0;i<y;i++){
if(res[i]==0){
cout << "  "<< i+1 << "         " << b[i] << "           " << "No block allocated" << endl;
}
else{ 
cout << "  "<< i+1 << "         " << b[i] << "           " << res[i] << endl;
}
}

}
