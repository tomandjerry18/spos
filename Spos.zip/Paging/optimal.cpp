#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	cout << "Enter the page string : ";
	cin >> s;
	vector <char> v(4,' ');
	vector<int> x(10,100);
	int y=100;
	for(int i=0;i<s.size();i++){
	
	for(int j=s.size()-1;j>=i;j--){
		x[s[i]-48] = y;
		y--;
		}
	if(v[0]==' '){
	v[0]=s[i];
	}
	else if(v[0]!=' ' and v[1]==' '){
	v[1]=s[i];
	}
	else if(v[0]!=' ' and v[1]!=' ' and v[2]==' ' ){
	v[2]=s[i];
	}
	else if(v[0]!=' ' and v[1]!=' ' and v[2]!=' ' and v[3]==' '){
	v[3]=s[i];
	}
	
	else{
	if(s[i]!=v[0] and s[i]!=v[1] and s[i]!=v[2] and s[i]!=v[3]){
		if(x[v[0]-48]>x[v[1]-48] and x[v[0]-48]>x[v[2]-48] and x[v[0]-48]>x[v[3]-48]){
		v[0]=s[i];
		}
		
		else if(x[v[1]-48]>x[v[0]-48] and x[v[1]-48]>x[v[2]-48] and x[v[1]-48]>x[v[3]-48]){
		v[1]=s[i];
		}
		
		else if(x[v[2]-48]>x[v[1]-48] and x[v[2]-48]>x[v[0]-48] and x[v[2]-48]>x[v[3]-48]){
		v[2]=s[i];
		}
		
		else if(x[v[3]-48]>x[v[0]-48] and x[v[3]-48]>x[v[1]-48] and x[v[3]-48]>x[v[2]-48]){
		v[3]=s[i];
		}
		
		
	   }
		
	}
	
	
	
	
	cout << v[0] << " " << v[1] << " " << v[2] <<" " <<  v[3] <<  endl;

}

}

