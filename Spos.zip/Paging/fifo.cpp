#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	cout << "Enter the paging string : ";
	cin >> s;
	int x = 0;
	
	vector <char> v(3,' ');
	for(int i=0;i<s.size();i++){
	if(v[0]==' '){
	v[0]=s[i];
	}
	else if(v[0]!=' ' and v[1]==' '){
	v[1]=s[i];
	}
	else if(v[0]!=' ' and v[1]!=' ' and v[2]==' ' ){
	v[2]=s[i];
	}
	
	else{
		if(s[i]!=v[0] and s[i]!=v[1] and s[i]!=v[2]){
	v[x]=s[i];
	x++;
	if(x==3){
	x=0;
	}
	}
}
	
	
	
	cout << v[0] << " " << v[1] << " " << v[2] << " " << endl;
	}

}

