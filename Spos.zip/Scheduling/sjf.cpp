#include<bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cout << "Enter the number of processes : ";
	cin >> n;
	vector<vector<int>> v(n,vector<int> (7,0));
	vector<pair<int,int>> a;
	
	for(int i=0;i<n;i++){
	cout << "Enter the arrival and burst time of process " << i+1 << ": " ;
	cin >> v[i][1] >> v[i][0];
	v[i][6]=i;
	} 
	sort(v.begin(),v.end());
	
	
	vector<int> b;
	int k=0;
	while(k<n){
	for(int i=0;i<n;i++){
	if(v[i][6]==k){
	b.push_back(i);
	}
	}
	k++;
	}
	for(int i=0;i<n;i++){
		if(i==0){
		a.push_back(make_pair(v[i][1],v[i][0]+v[i][1]));
		}
		
		else{
			if(a.back().second >= v[i][1]){
				a.push_back(make_pair(a.back().second,a.back().second+v[i][0]));
			}
			else{
				a.push_back(make_pair(v[i][1],v[i][0]+v[i][1]));
			}
		}
	
	}
	
	for(int i=0;i<n;i++){
		v[i][2] = a[i].second;
	}
	
	for(int i=0;i<n;i++){
		v[i][3] = a[i].second-v[i][1];
	}
	
	for(int i=0;i<n;i++){
		v[i][4] = v[i][3]-v[i][0];
	}
	
	for(int i=0;i<n;i++){
		v[i][5] = a[i].first-v[i][1];
	}
	
	cout << "Process  " << "Arrival  " << "Burst  " << "Completion " << "TAT  " << "WAT  " << "RT  " << endl;
	int i=0;
		for(int j=0;j<n;j++){
	
	    cout << "P" << i << "         " << v[b[j]][1] << "       " << v[b[j]][0] << "      " << v[b[j]][2] << "      " << v[b[j]][3] << "      " << v[b[j]][4] << "      " << v[b[j]][5] << endl;
	    i++;
		
	    }
    
    
    cout << "Ghantt Chart " << endl;
    
    if(a[0].first != 0){
    cout << "0" << " ";
    }
    for(int i=0;i<n;i++){
    if(a[i].second != a[i+1].first){
    cout << a[i].first << " " << a[i].second << " ";
    }
    else{
    cout << a[i].first << " ";
	}
    }
    


}
