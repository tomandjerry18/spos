#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    //cout << "Enter the number of processes: ";
    cin >> n;
    vector<vector<int>> v(n, vector<int>(6, 0));

    int t;
    //cout << "Enter time quantum: ";
    cin >> t;

    for (int i = 0; i < n; i++) {
        //cout << "Enter the priority, arrival and burst time of process " << i + 1 << ": ";
        cin >> v[i][0] >> v[i][1] >> v[i][2];
    }
    
    vector <int> bur;
    for(int i=0;i<n;i++){
    bur.push_back(v[i][2]);
    }

    int cnt = 0, sum = 0;

    for (int i = 0; i < n; i++) {
        sum += v[i][2];
    }
    
    vector<pair<int,int>> q;
    vector <bool> vis(n,0);
    vector<pair<int,int>> c;
    
    if(v[0][2]>t){
    cnt+=t;
    q.push_back(make_pair(v[0][0],0));
    v[0][2]-=t;
    c.push_back(make_pair(0, cnt));
    }
    
    
 
    while (cnt < sum) {
        for(int i=0;i<n;i++){
        int mx = 0,ind=0;
        
        sort(q.begin(),q.end());
        int x = q[q.size()-1].second;
        
        if (v[x][2] >= t) {
            cnt += t;
            c.push_back(make_pair(x, cnt));
            v[x][2] -= t;
            
        } else if (v[x][2] > 0 && v[x][2] < t) {
            cnt += v[x][2];
            c.push_back(make_pair(x, cnt));
            v[x][2] = 0;
            
        }
        if(v[x][2]==0) q.pop_back();

        vis[x] = 1;

        for (int i = 0; i < n; i++) {
            if (!vis[i] && v[i][1] <= cnt && i != x) {
                q.push_back(make_pair(v[i][0],i));
            }
        }

        if (v[x][2] > 0) {
            q.push_back(make_pair(v[x][0],x));
        }
        
        
        }
    }
    
    cout << "Ghantt Chart ";
    cout << "0 " ;
    for (int i=0;i<c.size()-1;i++) {
    if(c[i].first != c[i+1].first){
    cout << c[i].second << " ";
    }
    }
    
    cout << endl;
    
    for(int i=0;i<n;i++){
    	for(int j=c.size()-1;j>=0;j--){
    	if(c[j].first == i){
    	v[i][3]=c[j].second;
    	break;
    	}
    }
    }
    
    for(int i=0;i<n;i++){
    v[i][4]=v[i][3]-v[i][1];
    }
    
    for(int i=0;i<n;i++){
    v[i][5]=v[i][4]-bur[i];
    }
    
	
	cout << "Process  " << "Arrival  " << "Burst  " << "Completion " << "TAT  " << "WAT  " << "RT  " << endl;
    for(int i=0;i<n;i++){
        cout << "P" << i << "         " << v[i][1] << "       " << bur[i] << "      " << v[i][3] << "      " << v[i][4] << "      " << v[i][5] << endl;
    }

    
    cout << endl;
    return 0;
}

