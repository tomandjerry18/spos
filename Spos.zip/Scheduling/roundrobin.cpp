#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    cout << "Enter the number of processes: ";
    cin >> n;
    vector<vector<int>> v(n, vector<int>(6, 0));

    int t;
    cout << "Enter time quantum: ";
    cin >> t;

    for (int i = 0; i < n; i++) {
        cout << "Enter the arrival and burst time of process " << i + 1 << ": ";
        cin >> v[i][0] >> v[i][1];
    }
    
    vector <int> bur;
    for(int i=0;i<n;i++){
    bur.push_back(v[i][1]);
    }

    int cnt = 0, sum = 0;

    for (int i = 0; i < n; i++) {
        sum += v[i][1];
    }

    queue<int> b;
    b.push(0);
    vector<pair<int, int>> c;

    vector<bool> vis(n, 0);

    while (cnt < sum) {
        int x = b.front();
        b.pop();

        if (v[x][1] >= t) {
            cnt += t;
            c.push_back(make_pair(x, cnt));
            v[x][1] -= t;
        } else if (v[x][1] > 0 && v[x][1] < t) {
            cnt += v[x][1];
            c.push_back(make_pair(x, cnt));
            v[x][1] = 0;
        }

        vis[x] = 1;

        for (int i = 0; i < n; i++) {
            if (!vis[i] && v[i][0] <= cnt && i != x) {
                b.push(i);
            }
        }

        if (v[x][1] > 0) {
            b.push(x);
        }
    }

    cout << "Ghantt Chart ";
    cout << "0 " ;
    for (auto i : c) {
        cout << i.second << " ";
    }
    cout << endl;
    
    for(int i=0;i<n;i++){
    	for(int j=c.size()-1;j>=0;j--){
    	if(c[j].first == i){
    	v[i][2]=c[j].second;
    	break;
    	}
    }
    }
    
    for(int i=0;i<n;i++){
    v[i][3]=v[i][2]-v[i][0];
    }
    
    for(int i=0;i<n;i++){
    v[i][4]=v[i][3]-bur[i];
    }
    
    for(int i=0;i<n;i++){
    if(i==0){
    v[i][5] = 0;
    }
    	for(int j=0;j<c.size();j++){
    	
    	if(c[j].first == i){
    	v[i][5]=c[j-1].second-v[i][0];
    	break;
    	}
    }
    }
	
	cout << "Process  " << "Arrival  " << "Burst  " << "Completion " << "TAT  " << "WAT  " << "RT  " << endl;
    for(int i=0;i<n;i++){
        cout << "P" << i << "         " << v[i][0] << "       " << bur[i] << "      " << v[i][2] << "      " << v[i][3] << "      " << v[i][4] << "      " << v[i][5] << endl;
    }

    return 0;
}
